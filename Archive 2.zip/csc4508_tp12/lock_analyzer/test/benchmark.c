/* -*- c-file-style: "GNU" -*- */
/*
 * Copyright (C) CNRS, INRIA, Université Bordeaux 1, Télécom SudParis
 * See COPYING in top-level directory.
 */

#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <inttypes.h>

/* Number of iterations */
#define ITER 1000000
/* Number of threads */
#define NTH 3

#define TIME_DIFF(t1, t2) \
        ((t2.tv_sec - t1.tv_sec) * 1000000 + (t2.tv_usec - t1.tv_usec))

/* Only used during thread creating to make sure that the thread
 * got the correct args.
 */
sem_t thread_ready;

/* Block/unblock a thread */
sem_t sem[NTH];

pthread_mutex_t mutex;

/* delay (in microsecond) between each call to mutex_lock */
int contention_delay = 0;

/* Fake computation of usec microseconds */
void compute(int usec) {
  struct timeval tv1, tv2;
  gettimeofday(&tv1, NULL);
  do {
    gettimeofday(&tv2, NULL);
  } while (TIME_DIFF(tv1, tv2) < usec);
}

uint64_t sum = 0;
void* f_thread(void* arg) {
  int my_id = *(int*) arg;

  /* Notify the main thread that we got the args */
  sem_post(&thread_ready);

  printf("Running thread #%d\n", my_id);
  struct timeval tv1, tv2;
  gettimeofday(&tv1, NULL);

  int i;
  for (i = 0; i < ITER; i++) {
    /* compute for 1ms */
    pthread_mutex_lock(&mutex);
    sum++;
    pthread_mutex_unlock(&mutex);
    compute(contention_delay);
  }

  gettimeofday(&tv2, NULL);
  double duration = TIME_DIFF(tv1, tv2);
  
  printf("End of thread #%d\n", my_id);

  if(my_id == 0) {
    printf("Thread %d did %d loops in %lf usec (%lf usec per loop)\n",
	   my_id, ITER, duration, duration/ITER);
  }
  return NULL;
}

int main(int argc, char**argv) {
  pthread_t tid[NTH];
  int i;
  sum = 0;
  
  pthread_mutex_init(&mutex, NULL);

  sem_init(&thread_ready, 0, 0);
  for (i = 0; i < NTH; i++)
    sem_init(&sem[i], 0, 0);

  for (i = 0; i < NTH; i++) {
    pthread_create(&tid[i], NULL, f_thread, &i);
    sem_wait(&thread_ready);
  }

  /* Unblock the first thread so that it can start working */
  sem_post(&sem[0]);

  for (i = 0; i < NTH; i++) {
    pthread_join(tid[i], NULL);
  }
  if(sum != NTH*ITER) {
    fprintf(stderr, "Error: some increments were lost ! (sum=%"PRIu64" instead of %"PRIu64")\n", sum, (uint64_t)NTH*ITER);
    abort();
  }
  return 0;
}
