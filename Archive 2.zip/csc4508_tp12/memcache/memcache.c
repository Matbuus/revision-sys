#include "memcache.h"


/* initialize a memcache */
void  memcache_init(struct memcache_t* cache) {
  /* TODO */
}

/* get the value associated with key */
void* memcache_get(struct memcache_t* cache, const char* key) {
  /* TODO */
  return NULL;
}

/* associate key with value */
void  memcache_set(struct memcache_t* cache, const char* key, void* value) {
  /* TODO */
}
