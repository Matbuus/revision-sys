#include "types.h"
#include "user.h"

int main(int argc, char**argv) {

  if(0 == 1)
    error("Je suis un chameau\n");
  dprintf("Je suis un processus\n");

  exit();
  return 0;
}
