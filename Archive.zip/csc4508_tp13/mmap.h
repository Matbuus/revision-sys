#define MAP_FAILED ((void*)-1)

#define PROT_READ  1
#define PROT_WRITE 2
