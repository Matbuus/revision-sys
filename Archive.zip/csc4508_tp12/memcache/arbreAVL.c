#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include "arbreAVL.h"

/* Fonction utilitaire pour recuperer la hauteur d'un arbre
   NB : Renvoie 0 si node est NULL
*/
static int height(const struct Node *node) {
  if (!node)
    return 0;
  return node->height;
}

/* Fonction utilitaire renvoyant le maximum de deux entiers
 */
static int max(const int a, const int b) {
  return (a > b)? a : b;
}

/* Procedure qui recalcule le champs height de node a partir de la
   hauteur de ses noeuds fils
*/
static void updateHeight(struct Node *node) {
  /* TODO (question 1.a) */
}

/* Fonction (interne) renvoyant le noeud contenant la cle key dans le 
   sous-arbre node.
   NB : Renvoie NULL si la cle n'a pas ete trouvee
*/
static struct Node *getKeyNode(struct Node* node, const char *key) {
  /* TODO (question 1.c) */
  return NULL;
}

/* Fonction renvoyant le nombre de noeuds dans le sous-arbre node
   NB : Renvoie 0 si l'arbre ne contient pas de noeud
*/
int nbNode(const struct Node* node) {
  /* TODO (question 1.a)*/
  return 0;
}

/* Fonction liberant tous les elements du sous-arbre node
   (y compris node)
   Renvoie systematiquement NULL
*/
struct Node *release(struct Node *node) {
  /* TODO (question 1.b) */
  return NULL;
}

/* Fonction (interne) pour creer un noeud pour stocker la cle
   NB :
      - La cle est recopiee dans une zone memoire allouee dans newNode
      - Les pointeurs left et right sont a NULL
      - Le champ height est initialise a 1 (ce noeud est considere comme 
        une feuille autonome).
*/
static struct Node* newNode(const char *key, const char* value)
{
  /* TODO (question 1.a) */
  return NULL;
}

// Rotation droite d'un sous-arbre de racine z
static struct Node *rightRotate(struct Node *z) {
  // Pour info, les noms de variable sont inspires des noms
  // des noeuds dans les figures de l'enonce.
  struct Node *y = z->left;
  struct Node *T3 = y->right;
 
  // Rotation
  y->right = z;
  z->left = T3;
 
  // MAJ des hauteurs
  updateHeight(z);
  updateHeight(y);
 
  // On renvoie la nouvelle racine du sous-arbre
  return y;
}

// Rotation gauche d'un sous-arbre de racine z
static struct Node *leftRotate(struct Node *z) {
  // Pour info, les noms de variable sont inspires des noms
  // des noeuds dans les figures de l'enonce.
  struct Node *y = z->right;
  struct Node *T2 = y->left;
 
  // Rotation
  y->left = z;
  z->right = T2;
 
  // MAJ des hauteurs
  updateHeight(z);
  updateHeight(y);
 
  // On renvoie la nouvelle racine du sous-arbre
  return y;
}

/* Fonction recursive qui insere key dans le sous-arbre de racine node.
   Renvoie la nouvelle racine de ce sous-arbre.
   NB : 1) un arbre binaire ne contient jamais deux fois la meme valeur.
           De ce fait, si la valeur existe deja, insert renvoie node, sans creer
           de nouveau noeud.
        2) Si node vaut NULL, renvoie un arbre constitue uniquement d'un noeud
           contenant cet arbre.
*/
struct Node* insert(struct Node* node, const char* key, const char *value) {
  /* 1. Insertion du noeud */

  /* TODO (question 1.a)*/
 
  /* 2. MAJ de la taille du noeud courant */

  /* TODO (question 1.a) */

  /* 3. Calcul du facteur balance du noeud courant */
  /* TODO (question 1.d) */

  // S'il est devenu desequilibre, il y a 4 cas

  // Cas Gauche-Gauche
  /* TODO (question 1.d) */

  // Cas Droite-Droite
  /* TODO (question 1.d) */

  // Cas Gauche-Droite
  /* TODO (question 1.d) */

  // Cas Droite-Gauche

  /* TODO (question 1.d) */

  return NULL;
}

/* Fonction renvoyant la hauteur de la cle key dans le sous-arbre node.
   NB : Renvoie 0 si la cle n'a pas ete trouvee
*/
int getKeyHeight(struct Node* node, const char *key) {
  struct Node *correspondingNode = getKeyNode(node, key);
  return correspondingNode ? height(correspondingNode) : 0;
}

/* Fonction (interne) renvoyant le nombre de noeuds trouves avant le
   noeud contenant key dans le sous-arbre key ou bien -1 si key n'est pas
   trouve.
*/
static void countNodesUntilKey(const struct Node* node,
			       const char *key,
			       int *nbNodesBeforeKey,
			       bool *found) {
  if (!node)
    return;
  countNodesUntilKey(node->left, key, nbNodesBeforeKey, found);
  int res = strcmp(key, node->key);
  if (res > 0) {
    *nbNodesBeforeKey += 1;
    countNodesUntilKey(node->right, key, nbNodesBeforeKey, found);
  } else if (res == 0) {
    *found = true;
  }
}

/* Fonction renvoyant le rang de la cle key dans le sous-arbre node.
   Par exemple :
     - Renvoie 0 si le noeud de la cle key est le noeud le plus en bas
       à gauche de l'arbre
     - Renvoie le nombre de noeuds dans l'arbre - 1 si le noeud de la cle
       key est le noeud le plus en bas à droite de l'arbre
   NB : Renvoie -1 si la cle n'a pas ete trouvee
*/
int getKeyRank(const struct Node* node, const char *key) {
  if (!node)
    return -1;
  bool found = false;
  int nbNodesBeforeKey = 0;
  countNodesUntilKey(node, key, &nbNodesBeforeKey, &found);
  return found ? nbNodesBeforeKey : -1;
}

/* Fonction renvoyant la valeur associee a une cle 
   (et NULL si la cle n'est pas trouvee)
*/
char *getValue(struct Node *node, const char *key) {
  struct Node *correspondingNode = getKeyNode(node, key);
  return correspondingNode ? correspondingNode->value : NULL;
  return NULL;
}

