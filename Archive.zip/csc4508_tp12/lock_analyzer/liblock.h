#ifndef LIBLOCK_H
#define LIBLOCK_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <stdint.h>
//#define DEBUG 1

#if DEBUG
#define DEBUG_PRINTF(...) printf(__VA_ARGS__)
#else
#define DEBUG_PRINTF(...) (void) 0
#endif


static void* get_callback(const char*fname) __attribute__((unused));
static void* get_callback(const char*fname){
  void* ret = dlsym(RTLD_NEXT, fname);
  if(!ret) {
    fprintf(stderr, "Warning: cannot find %s: %s\n", fname, dlerror());
  }
  return ret;
}

#define _do_intercept(...)                                  \
  enum intercepted_function {                               \
        __VA_ARGS__,                                        \
        NB_FUNCTIONS                                        \
  };                                                        \
                                                            \
  static char* function_names[] __attribute__((unused)) =   \
    {                                                       \
     #__VA_ARGS__ /* stringify */                           \
    }

    _do_intercept(mutex_lock,
                  mutex_trylock,
                  mutex_unlock,
                  mutex_init,
                  mutex_destroy,
                  cond_wait,
                  cond_timedwait,
                  cond_signal,
                  cond_broadcast,
                  cond_init,
                  cond_destroy);

#undef _do_intercept

enum event_type {
   function_entry,
   function_exit,
};

struct lock_event {
  uint64_t timestamp;
  void* ptr;
  pthread_t tid;
  enum intercepted_function function;
  enum event_type event_type;
} __attribute__((packed));


void enter_function(enum intercepted_function f, void* ptr);
void leave_function(enum intercepted_function f, void* ptr);

#endif
