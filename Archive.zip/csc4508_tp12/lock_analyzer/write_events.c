#include "liblock.h"
#include <time.h>
#include <assert.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>

_Atomic int nb_calls[NB_FUNCTIONS];
FILE* trace_file = NULL;

#define BUFFER_SIZE 1000000
struct lock_event buffer[BUFFER_SIZE];
_Atomic int next_event = 0;
_Atomic int nrecords=0;

struct timespec start_timestamp;
uint64_t get_timestamp() {
  struct timespec current_timestamp;
  clock_gettime(CLOCK_MONOTONIC, &current_timestamp);
  return (current_timestamp.tv_sec-start_timestamp.tv_sec)*1e9 +
    (current_timestamp.tv_nsec-start_timestamp.tv_nsec);
}

void flush_buffer() {
  printf("About to flush... nrecords=%d, buffer_size=%d\n", nrecords, BUFFER_SIZE);
  int ret = fwrite(buffer, sizeof(struct lock_event), nrecords, trace_file);
  assert(ret > 0);
  printf("flush done... ret = %d, nrecords= %d\n", ret, nrecords);
  nrecords -= BUFFER_SIZE;
  next_event -= BUFFER_SIZE;
}

void record_event(enum event_type event_type,
		  enum intercepted_function f,
		  void* ptr) {
  int event_index = next_event++;

  while(event_index >= BUFFER_SIZE) {
    if(event_index == BUFFER_SIZE) {
      flush_buffer();
    } else {
      while(next_event > BUFFER_SIZE) sched_yield();
    }
    
    event_index -= BUFFER_SIZE;
  }

 if(event_index < BUFFER_SIZE) {
    struct lock_event *event = &buffer[event_index];
    event->function=f;
    event->event_type = event_type;
    event->timestamp = get_timestamp();
    event->ptr = ptr;
    event->tid = pthread_self();
    nrecords++;
  }
}

void enter_function(enum intercepted_function f, void* ptr) {
  DEBUG_PRINTF("Entering %s\n", function_names[f]);
  assert(trace_file);
  nb_calls[f]++;
  record_event(function_entry, f, ptr);
}

void leave_function(enum intercepted_function f, void* ptr) {
  DEBUG_PRINTF("Leaving %s\n", function_names[f]);
  assert(trace_file);
  record_event(function_exit, f, ptr);
}

static void __write_events_init(void) __attribute__((constructor));
static void __write_events_init(void) {
  DEBUG_PRINTF("[LIBLOCK] initializing write_events\n");
  for(int i=0; i<NB_FUNCTIONS; i++) {
    nb_calls[i]=0;
  }

  clock_gettime(CLOCK_MONOTONIC, &start_timestamp);

  trace_file=fopen("trace.dat", "w");
  assert(trace_file);
}

static void __write_events_conclude(void) __attribute__((destructor));
static void __write_events_conclude(void) {
  DEBUG_PRINTF("[LIBLOCK] finalizing write_events\n");

  for(int i=0; i<NB_FUNCTIONS; i++) {
    if(nb_calls[i]!=0) {
      printf("%s: %d\n", function_names[i], nb_calls[i]);
    }
  }

  flush_buffer();

  assert(trace_file);
  fclose(trace_file);
}

